DATAMEX COLLEGE OF SAINT ADELINE
Student: Marcial Lawrence Jr V. Caronan
Section: 4th Year BSIT Set A
Date: September 17, 2026
Course: Data Analysis Midterm Exam (Hands-On Examination)

CONTENTS:
1. 4A_Marcial_Lawrence_Jr_V_Caronan.xlsx - Original authentic graded Excel workbook with all 5 sheets and formulas
2. Raw_Data.csv - Complete 50 customer transaction records (T1000 to T1049)
3. Exam_Tasks.csv - Complete calculations for Tasks 1 through 11 (Descriptive Stats, Student Segmentation, Day of Week, Service Volume, Correlation r=0.7556, Top 5)
4. Data_Dictionary.csv - Detailed 11-variable schema definition and constraints
5. Recommendations.csv - 4 evidence-based business recommendations
